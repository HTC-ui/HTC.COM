
async function loadProducts(){
  const res = await fetch('products.json');
  const items = await res.json();
  return items;
}

const state = { q:'', cat:'All' };

function render(items){
  const container = document.getElementById('grid');
  const q = state.q.toLowerCase();
  const cat = state.cat;
  container.innerHTML = '';
  items
    .filter(p => (cat==='All' || p.category===cat) && (p.name.toLowerCase().includes(q)))
    .forEach(p => {
      const card = document.createElement('div');
      card.className='card';
      card.innerHTML = `
        <span class="badge">${p.category}</span>
        <img src="${p.image}" alt="${p.name}">
        <h3>${p.name}</h3>
        <div class="small">${p.unit}</div>
        <div class="price">₹ ${p.price}</div>
        <button class="snipcart-add-item" 
          data-item-id="${p.id}"
          data-item-price="${p.price}"
          data-item-url="/"
          data-item-description="${p.name}"
          data-item-image="${p.image}"
          data-item-name="${p.name}"
        >Add to Cart</button>
      `;
      container.appendChild(card);
    });
}

async function init(){
  const items = await loadProducts();
  const cats = ['All', ...new Set(items.map(i=>i.category))];
  const catbar = document.getElementById('catbar');
  cats.forEach(c => {
    const btn = document.createElement('button');
    btn.textContent = c;
    btn.className = c==='All' ? 'active' : '';
    btn.onclick = () => {
      document.querySelectorAll('#catbar button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active'); state.cat=c; render(items);
    };
    catbar.appendChild(btn);
  });
  document.getElementById('search').addEventListener('input', (e)=>{ state.q=e.target.value; render(items); });
  render(items);
}
window.addEventListener('DOMContentLoaded', init);
